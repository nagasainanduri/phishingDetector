const CONFIG = {
    BACKEND_URL: 'https://phishguard-h92c.onrender.com'
};
